fun main() {
    sikusiku()
}
fun sikusiku (){
    for (i in 1..8){
        for (j in 1..i){
            print("*")
        }
        println()
    }
}