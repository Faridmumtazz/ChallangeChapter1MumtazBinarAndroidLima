fun main() {
    plusBintang()
}
fun plusBintang(){
    val n = 5
    for (i in 1 until(n + 1)){
        for (j in 1 until (n + 1)) {
            if (j % 3 == 0){
                print("* ")
            }else if (i % 3 == 0){
                print("* ")
            }else {
                print(" ")
            }
        }
        println("")
    }
}